"use strict";
function Mostrar() {
    var nombre = document.getElementById("textNombre").value;
    var edad = (Number)(document.getElementById("textEdad").value);
    //let edad: number = (<HTMLInputElement> document.getElementById("textEdad")).value;
    //edad=parseInt(edad);
    console.log(nombre + " " + edad);
    alert(nombre + " " + edad);
}
//# sourceMappingURL=ejercicio2.js.map