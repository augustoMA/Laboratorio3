function Mostrar():void
{
   let nombre: string = (<HTMLInputElement> document.getElementById("textNombre")).value;
   let edad: number = (Number)((<HTMLInputElement> document.getElementById("textEdad")).value);
   //let edad: number = (<HTMLInputElement> document.getElementById("textEdad")).value;
   //edad=parseInt(edad);
   console.log(nombre+" "+edad);
   alert(nombre+" "+edad);
}
